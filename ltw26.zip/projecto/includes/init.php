<?php
  include_once('includes/session.php');
  include_once('database/connection.php');
  include_once('templates/common/header.php');
?>
