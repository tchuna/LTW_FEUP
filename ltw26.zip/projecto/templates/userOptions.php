<div id="options">
    <form action="search.php" method="get">
      <input id="search-box" name="query"
      placeholder="Search My Items, Lists or Projects" title="Search"
      autocomplete="off" type="search">
    </form>

    <div class="edit">
      <a href="userEditProfile.php"> Edit my profile </a>
    </div>
</div>
