<h2 class="title" id="profile"> <?= $user['username'] ?></h2>
<ul>
    <li><p> <?= $user['name'] ?> </p></li>
    <li><p> <?= $user['email'] ?> </p></li>
    <li><p> From <?= $user['location'] ?> </p></li>
    <li><p><?= $age ?> years old</p></li>
</ul>
