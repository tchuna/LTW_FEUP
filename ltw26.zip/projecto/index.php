<?php
    include_once('includes/init.php');
    include_once('templates/signup.php');
    include_once('templates/common/footer.php');
?>
