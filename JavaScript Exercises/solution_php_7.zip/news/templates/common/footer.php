<footer>
  <p>&copy; Fake News, 2017</p>
</footer>
</body>
</html>
